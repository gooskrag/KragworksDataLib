class APIConfig:
  __conf = {
    "token": "asdfasdf",
  }
  __setters = ["token"]

  @staticmethod
  def config(name):
    return APIConfig.__conf[name]

  @staticmethod
  def set(name, value):
    if name in APIConfig.__setters:
      APIConfig.__conf[name] = value
    else:
      raise NameError("Name not accepted in set() method")
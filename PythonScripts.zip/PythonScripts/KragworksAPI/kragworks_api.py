from json.decoder import JSONDecodeError
from typing import get_type_hints

import requests
import json

from requests.models import Response


class KragworksAPI:

            
    __conf = {}

    def __init__(self):
        self.loadConfig()
        
        if (self.__conf["token"] == "none"):
            self.askForToken()
        if (self.__conf["baseUrl"] == "none"):
            self.askForUrl()

    def loadConfig(self):
        try:
            file = open('apiSettings.config', 'r')
            data = json.load(file)
            if data is None:
                self.createConfigFile()
            else:
                self.__conf["token"] = data["token"]
                self.__conf["baseUrl"] = data["baseUrl"]
        except JSONDecodeError:
            self.createConfigFile()
        except FileNotFoundError:
            self.createConfigFile()

    def createConfigFile(self):
        newFile = open('apiSettings.config', 'w')
        newFile.write('{ "token": "none", "baseUrl" : "none" }')
        newFile.close()
        self.loadConfig()

    def setConfigFile(self):
        with open('apiSettings.config', 'w') as newFile:
            json.dump(self.__conf, newFile)
            newFile.close()

    def askForToken(self):
        token = input("Please enter API Token (leave empty to skip): ")
        if (token in ["s", "S", "Skip", "skip", ""]):
            return
        else:
            self.setToken(token)
        # print("Token set!")

    def askForUrl(self):
        baseUrl = input("Please enter Base URL (leave empty to skip): ")
        if (baseUrl in ["s", "S", "Skip", "skip", ""]):
            return
        else:
            self.setBaseUrl(baseUrl)

    def getToken(self):
        return self.__conf["token"]

    def setToken(self, token):
        self.__conf["token"] = token
        self.setConfigFile()

    def setBaseUrl(self, baseUrl):
        self.__conf["baseUrl"] = baseUrl
        self.setConfigFile()

    def get(self, url, params = {}) -> Response:
        if(self.__conf["token"] is None):
            self.loadConfig()

        token = 'Bearer ' + self.__conf["token"]
        headers = {"Authorization": token}
        return requests.get(self.__conf["baseUrl"] + url, headers=headers, params=params)

    def post(self, url, data) -> Response: 
        if(self.__conf["token"] is None):
            self.loadConfig()

        token = 'Bearer ' + self.__conf["token"]
        headers = {"Authorization": token, "content-type" : "application/json"}
        response = requests.post(self.__conf["baseUrl"] + url,json = data, headers=headers)
        return response

    def put(self, url, data) -> Response: 
        if(self.__conf["token"] is None):
            self.loadConfig()

        token = 'Bearer ' + self.__conf["token"]
        headers = {"Authorization": token, "content-type" : "application/json"}
        response = requests.put(self.__conf["baseUrl"] + url,json = data, headers=headers)
        return response

    def delete(self, url) -> Response: 
        if(self.__conf["token"] is None):
            self.loadConfig()

        token = 'Bearer ' + self.__conf["token"]
        headers = {"Authorization": token, "content-type" : "application/json"}
        response = requests.delete(self.__conf["baseUrl"] + url, headers=headers)
        return response

if __name__ == "__main__":
    KragworksAPI = KragworksAPI()
    params = {
       
    }

    data =  {
        "id" : 53,
        "name": "Python Update",
        "streetAddress": "1209 Morrier Ln",
        "city": "Yakima",
        "state": "Washington",
        "zipCode": "98901",
        "isActive": "true",
        "shortName": "BTL",
        "blocks": [],
    }

    url: str = 'farms/' + str(data["id"])
    response: Response = KragworksAPI.get(url)
    print(response.text)
